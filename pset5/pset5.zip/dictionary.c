/****************************************************************************
 * dictionary.c
 *
 * Computer Science 50
 * Problem Set 6
 *
 * Implements a dictionary's functionality.
 ***************************************************************************/

#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#include "dictionary.h"
#define SIZE 5000

node* hash_table[SIZE] = {NULL};
int words = 0;

/*
 * Returns true if word is in dictionary else false.
 */

bool check(const char* word)
{
  int length = strlen(word);
  char lword[length + 1];
  strcpy(lword, word);
  for(int i = 0; i < length; i++) {
    if(isupper(lword[i]))
      lword[i] = tolower(word[i]);
  }

  int index = hash(lword);

  if (hash_table[index] == NULL)
    return false;

  if (strcmp(hash_table[index]->word, lword) == 0)
    return true;

  node* search = hash_table[index]->next;
  if (search != NULL)
  {
    while (search != NULL)
    {   
      if (strcmp(search->word, lword) == 0)
        return true;
      search = search->next;
    }
    return false;
  }
  else
    return false;
}


/*
 * Loads dictionary into memory.  Returns true if successful else false.
 */

bool load(const char* dict)
{   
  FILE* dictionary = fopen(dict, "r");
  if (dictionary == NULL)
  {
    printf("Could not open file %s.\n", dict);
    return 1;
  }

  while (!(feof(dictionary)))
  {
    node* n = malloc(sizeof(node));
    if(n == NULL)
    {
      fclose(dictionary);
      return false;
    }

    fscanf(dictionary, "%s", n->word);
    int index = hash(n->word);

    if (hash_table[index] == NULL)
    {
      hash_table[index] = n;
      n->next = NULL;
    }
    else if(hash_table[index] != NULL)
    {
      n->next = hash_table[index]->next;
      hash_table[index]->next = n;
    }
    words++;
  }
  fclose(dictionary);
  return true;
}

int hash(const char* word)
{
  int result = 0;
  int n = strlen(word);
  for (int i = 0; i < n; i++)
  {
    result += word[i];
  }
  return result % SIZE;
}

/*
 * Returns number of words in dictionary if loaded else 0 if not yet loaded.
 */

unsigned int size(void)
{
  return words - 1;
}


/*
 * Unloads dictionary from memory.  Returns true if successful else false.
 */

bool unload(void)
{
  // iterate over the whole hash table
  for(int index = 0; index < SIZE; index++)
  {
    // if current hash index is not empty free all elements in the index
    if(hash_table[index] != NULL)
      freehash(hash_table[index]);
  }
  return true;
}

/*
 * void
 * freehash(node *next)
 *
 * Frees all allocated memory within the hash table
 */

void freehash(node* next)
{
  // if the current node isn't the last element, free the next node first
  if(next->next != NULL)
    freehash(next->next);
  free(next);
}
